﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Thread_Testing.Models;

namespace Thread_Testing
{
    class BottleMachine
    {
        public Queue<Bottle> Bottles { get; set; }
    }
}
